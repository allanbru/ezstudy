#import asyncio
#import chess
##import chess.uci
#import chess.engine
#import chess.pgn
#import io
#from stockfish import Stockfish
##Let's try our code with the starting position of chess:

#stockfish = Stockfish(r'F:\Downloads\stockfish_13_win_x64\stockfish_13_win_x64.exe')

## set position by FEN:
#stockfish.set_fen_position("rn1qr1k1/1b1nppb1/p2p2pp/1ppP4/4P3/2NB1NB1/PPP2PPP/R2QR1K1 w - - 0 16")

#print(stockfish.get_best_move())
#print(stockfish.get_evaluation())
print("a")