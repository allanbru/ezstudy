@extends('adminlte::page')

@section('plugins.Chartjs', true)

@section('title', 'Início')

@section('content_header')
    <h1>Início</h1>
@endsection

@section('content')

    <div class="row">
        <div class="col-lg-4 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3>3</h3>
                    <p>Módulos</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="{{route('modules.index')}}" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-4 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3>3</h3>
                    <p>Cards essa semana</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="{{route('modules.index')}}" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-4 col-6">
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3>3</h3>
                    <p>Cards para revisar</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="{{route('modules.index')}}" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

@endsection