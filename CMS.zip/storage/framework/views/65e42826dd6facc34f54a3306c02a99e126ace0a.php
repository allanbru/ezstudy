

<?php $__env->startSection("title", "Cadastro"); ?>
<?php echo $__env->make("adminlte::auth/register", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/register.blade.php ENDPATH**/ ?>