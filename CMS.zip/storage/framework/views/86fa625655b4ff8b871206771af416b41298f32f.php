

<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection("content_header"); ?>
    <h1>Meus Usuários
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-success"><i class="fas fa-fw fa-plus"></i></a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                   <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Ações</th>
                    </tr> 
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('users.edit', ['user' => $user->id])); ?>" class="btn btn-sm btn-info"><i class="fas fa-pen"></i></a>
                                <?php if($loggedId !== intval($user->id)): ?>
                                    <form class="d-inline" method="post" action="<?php echo e(route('users.destroy', ['user' => $user->id])); ?>" onSubmit="return confirm('Tem certeza?')">
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <small><?php echo e($users->links("pagination::bootstrap-4")); ?></small>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/users/index.blade.php ENDPATH**/ ?>