

<?php $__env->startSection('title', 'Páginas'); ?>

<?php $__env->startSection("content_header"); ?>
    <h1>Minhas páginas
        <a href="<?php echo e(route('pages.create')); ?>" class="btn btn-sm btn-success"><i class="fas fa-fw fa-plus"></i></a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                   <tr>
                        <th width="50">ID</th>
                        <th>Título</th>
                        <th width="150">Ações</th>
                    </tr> 
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($page->id); ?></td>
                            <td><?php echo e($page->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('home')); ?>/<?php echo e($page->slug); ?>" target="_blank" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="Visualizar"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('pages.edit', ['page' => $page->id])); ?>" class="btn btn-sm btn-info"  data-toggle="tooltip" title="Editar"><i class="fas fa-pen"></i></a>
                                <form class="d-inline" method="post" action="<?php echo e(route('pages.destroy', ['page' => $page->id])); ?>" onSubmit="return confirm('Tem certeza?')">
                                    <?php echo method_field("DELETE"); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"  data-toggle="tooltip" title="Excluir"><i class="fas fa-trash"></i></a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <small><?php echo e($pages->links("pagination::bootstrap-4")); ?></small>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>