

<?php $__env->startSection('plugins.Chartjs', true); ?>

<?php $__env->startSection('title', 'Início'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Início</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-4 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3>3</h3>
                    <p>Módulos</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="<?php echo e(route('modules.index')); ?>" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-4 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3>3</h3>
                    <p>Cards essa semana</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="<?php echo e(route('modules.index')); ?>" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-4 col-6">
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3>3</h3>
                    <p>Cards para revisar</p>
                </div>
            

                <div class="icon">
                    <i class="fas fa-fw fa-th-large"></i>
                </div>

                <a href="<?php echo e(route('modules.index')); ?>" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/home.blade.php ENDPATH**/ ?>