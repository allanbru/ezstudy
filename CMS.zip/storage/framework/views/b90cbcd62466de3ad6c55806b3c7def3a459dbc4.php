

<?php $__env->startSection('title', 'Configurações'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Configurações do Site</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissable">
            <h5><i class="icon fas fa-ban"></i> Erro:</h5>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-success alert-dismissable">
            <i class="icon fas fa-check"></i> <?php echo e(session('warning')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('settings.save')); ?>" method="POST" class="form-horizontal">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Título do Site</label>
                    <div class="col-sm-10">
                        <input type="text" name="title" value="<?php echo e($settings['title']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Subtítulo</label>
                    <div class="col-sm-10">
                        <input type="text" name="subtitle" value="<?php echo e($settings['subtitle']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">E-mail de contato</label>
                    <div class="col-sm-10">
                        <input type="email" name="email" value="<?php echo e($settings['email']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Facebook</label>
                    <div class="col-sm-10">
                        <input type="text" name="facebook" value="<?php echo e($settings['facebook']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Twitter</label>
                    <div class="col-sm-10">
                        <input type="text" name="twitter" value="<?php echo e($settings['twitter']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Instagram</label>
                    <div class="col-sm-10">
                        <input type="text" name="instagram" value="<?php echo e($settings['instagram']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Sobre</label>
                    <div class="col-sm-10">
                        <input type="text" name="about" value="<?php echo e($settings['about']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Termos de Uso</label>
                    <div class="col-sm-10">
                        <input type="text" name="termsofuse" value="<?php echo e($settings['termsofuse']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Políticas de Privacidade</label>
                    <div class="col-sm-10">
                        <input type="text" name="privacypolicy" value="<?php echo e($settings['privacypolicy']); ?>" class="form-control" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Cor do fundo</label>
                    <div class="col-sm-10">
                        <input type="color" name="bgcolor" value="<?php echo e($settings['bgcolor']); ?>" class="form-control" style="width:60px" />
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Cor do Texto</label>
                    <div class="col-sm-10">
                        <input type="color" name="textcolor" value="<?php echo e($settings['textcolor']); ?>" class="form-control" style="width:60px" />
                    </div>
                </div>

                <div class="form-group row">
                    <button type="submit" class="btn btn-success btn-block">Salvar</button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>