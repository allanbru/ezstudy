

<?php $__env->startSection('title', 'Minha Partida'); ?>

<?php $__env->startSection("content_header"); ?>
    <h1>Minha partida</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        FEN: <?php echo e($fen); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/chess/game.blade.php ENDPATH**/ ?>