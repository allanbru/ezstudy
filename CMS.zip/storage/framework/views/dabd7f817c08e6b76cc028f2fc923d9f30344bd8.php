<?php $__env->startSection('title', 'EZStudy'); ?>

<?php $__env->startSection('content'); ?>

   <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <h1 class="mb-5"><?php echo e($front_config['subtitle']); ?></h1>
        </div>
        <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
          <div class="form-row">
            <div class="col-12 col-md-12">
              <a href="<?php echo e(route('register')); ?>" class="btn btn-block btn-lg btn-primary">Cadastre-se!</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/site/home.blade.php ENDPATH**/ ?>