

<?php $__env->startSection('title', $page['title']); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4">
    <div class="col-md-12 my-auto showcase-text">
        <h2><?php echo e($page['title']); ?></h2>
        <p class="lead mb-0">
            <?php echo $page['body']; ?>

        </p>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/site/page.blade.php ENDPATH**/ ?>