

<?php $__env->startSection('title', $module->title); ?>

<?php $__env->startSection("content_header"); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>
                Módulo: <?php echo e($module->title); ?>

                <a href="<?php echo e(route('modules.edit', ['module' => $module->id])); ?>" class="btn btn-sm btn-info"><i class="fas fa-pen"></i></a>
                <form class="d-inline" method="post" action="<?php echo e(route('modules.destroy', ['module' => $module->id])); ?>" onSubmit="return confirm('Tem certeza que deseja apagar <?php echo e($module->title); ?>?')">
                    <?php echo method_field("DELETE"); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></a>
                </form>
            </h1>
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 my-4">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <h1><?php echo e($card->front); ?></h1>
                        </div>
                        <div class="flip-card-back">
                            <h1><?php echo e($card->back); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    

    <style>
        /* The flip card container - set the width and height to whatever you want. We have added the border property to demonstrate that the flip itself goes out of the box on hover (remove perspective if you don't want the 3D effect */
        .flip-card {
        background-color: transparent;
        width: 300px;
        height: 200px;
        border: 1px solid #f1f1f1;
        perspective: 1000px; /* Remove this if you don't want the 3D effect */
        }

        /* This container is needed to position the front and back side */
        .flip-card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        text-align: center;
        transition: transform 0.8s;
        transform-style: preserve-3d;
        }

        /* Do an horizontal flip when you move the mouse over the flip box container */
        .flip-card:hover .flip-card-inner {
        transform: rotateY(180deg);
        }

        /* Position the front and back side */
        .flip-card-front, .flip-card-back {
        position: absolute;
        width: 100%;
        height: 100%;
        -webkit-backface-visibility: hidden; /* Safari */
        backface-visibility: hidden;
        }

        /* Style the front side (fallback if image is missing) */
        .flip-card-front {
        background-color: dodgerblue;
        color: white;
        }

        /* Style the back side */
        .flip-card-back {
        background-color: dodgerblue;
        color: white;
        transform: rotateY(180deg);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/modules/show.blade.php ENDPATH**/ ?>