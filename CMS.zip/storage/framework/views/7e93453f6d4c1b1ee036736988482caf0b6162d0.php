

<?php $__env->startSection('title', 'Meus Módulos'); ?>

<?php $__env->startSection("content_header"); ?>
    <h1>Meus Módulos
        <a href="<?php echo e(route('modules.create')); ?>" class="btn btn-sm btn-success"><i class="fas fa-fw fa-plus"></i></a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($module->title); ?></h3>
                        <p>3 cards</p>
                    </div>
                

                    <div class="icon">
                        <i class="<?php echo e($module->icon); ?>"></i>
                    </div>

                    <a href="<?php echo e(route('modules.show', ['module' => $module->id])); ?>" class="small-box-footer">Acessar <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    
    <small><?php echo e($modules->links("pagination::bootstrap-4")); ?></small>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\Desktop\Projetos\CMS\resources\views/admin/modules/index.blade.php ENDPATH**/ ?>