<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Card;
use App\Models\Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CardController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $error = 1;
        $result = "";
        $destroy_link = "";

        $front = $request->input('front');
        $back = $request->input('back');
        $module_id = intval($request->input('module'));
        
        if($front && $back && $module_id){
            
            $module = Module::find($module_id);
            if($module){
                if(intval($module->author) === intval(Auth::id())){
                    $card = new Card;
                    $card->front = $front;
                    $card->back = $back;
                    $card->module = $module_id;
                    $card->save();

                    $result = $card;
                    $error = 0;
                    $destroy_link = route('cards.destroy', ['card' => $card->id]);
                }else{
                    $result = "Você não pode inserir cartas nesse módulo";
                }
            } else{
                $result = "Módulo não encontrado";
            }

            
        }else{
            $result = "Você precisa preencher todos os campos";
        }

        return json_encode([
            "ERROR" => $error, 
            "RESULT" => $result,
            "DLINK" => $destroy_link
        ]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $card = Card::find($id);
        if($card){
            $module = Module::find($card->module);
        
            if($module && $module->author === intval(Auth::id())){
                $card->delete();
                return json_encode(1);
            }

        }
        
        return json_encode(0);
    }
}
