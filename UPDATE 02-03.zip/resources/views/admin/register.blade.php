@extends("adminlte::auth/register")

@section("title", "Cadastro")