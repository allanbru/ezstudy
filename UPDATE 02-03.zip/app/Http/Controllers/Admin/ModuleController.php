<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Card;
use App\Models\Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ModuleController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $modules = Module::where('author', intval(Auth::id()))->orderBy('created_at', 'DESC')->paginate(9);

        return view('admin.modules.index', [
            'modules' => $modules 
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.modules.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->only([
            'title',
            'icon'
        ]);

        $validator = Validator::make($data, [
            'title' => ['required', 'string', 'max:18'],
            'icon' => ['string', 'max:100']
        ]);

        if($validator->fails()){
            return redirect()->route("modules.create")
            ->withErrors($validator)
            ->withInput();
        }

        $module = new Module;
        $module->title = $data["title"];
        $module->icon = $data["icon"];
        $module->author = intval(Auth::id());
        $module->save();

        return redirect()->route("modules.index");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $module = Module::find($id);
        if($module && $module->author === intval(Auth::id())){
            $cards = Card::where("module", $id)->get();

            return view('admin.modules.show', [
                'module' => $module,
                'cards' => $cards
            ]);

        }

        return redirect()->route('admin');
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $module = Module::find($id);
        $cards = Card::where("module", $id)->get();

        if($module){
            return view("admin.modules.edit", [
                'module' => $module,
                'cards' => $cards
            ]);
        }

        return redirect()->route("modules.index");
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $module = Module::find($id);

        if($module){
            $data = $request->only([
                'title',
                'icon'
            ]);
    
            $validator = Validator::make($data, [
                'title' => ['required', 'string', 'max:18'],
                'icon' => ['string', 'max:100']
            ]);

            if($validator->fails()){
                return redirect()->route("modules.edit", [
                    'module' => $id
                ])
                ->withErrors($validator)
                ->withInput();
            }

            $module->title = $data['title'];
            $module->icon = $data['icon'];

            $module->save();
            
            if(count($validator->errors()) > 0){
                return redirect()->route("modules.edit", ["module" => $id])
                ->withErrors($validator);
            }

            $module->save();
        }
        return redirect()->route("modules.index");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $module = Module::find($id);
        
        if($module && $module->author === intval(Auth::id())){
            $module->delete();
        }

        return redirect()->route("modules.index");
    }
}
