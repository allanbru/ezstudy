<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Cards_history;
use App\Models\Cards_queue;
use App\Models\Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $loggedId =  intval(Auth::id());
        $modules_count = Module::where("author", $loggedId)->count();

        $solved_count = Cards_history::where([
            ['user', '=', $loggedId],
            ['created_at', '>=', strtotime('-7 days')]
        ])->count();

        $review_count = Cards_queue::where([
            ['user', '=', $loggedId],
            ['show_timestamp', '<=', time()]
        ])->count();

        $cardsByDay = Cards_history::selectRaw("day(created_at) as d, month(created_at) as m, count(*) as c")
        ->where([
            ['user', '=', $loggedId],
            ['created_at', '>=', strtotime('-7 days')]
        ])
        ->groupBy("m")
        ->groupBy("d")
        ->get();

        $graph = [];
        $graphColors = [];
        foreach($cardsByDay as $cardDay){
            $graph[$cardDay['d'] . "/" . $cardDay['m']] = intval($cardDay['c']);
            $graphColors[] = 'rgba('.rand(0, 255).', '.rand(0, 255).', '.rand(0, 255).')';
        }

        $graphLabels = json_encode(array_keys($graph));
        $graphValues = json_encode(array_values($graph));
        $graphColors = json_encode(array_values($graphColors));

        return view('admin.home',[
            'modules_count' => $modules_count,
            'solved_count' => $solved_count,
            'review_count' => $review_count,
            'graphLabels' => $graphLabels,
            'graphValues' => $graphValues,
            'graphColors' => $graphColors
        ]);
    }
        
}
